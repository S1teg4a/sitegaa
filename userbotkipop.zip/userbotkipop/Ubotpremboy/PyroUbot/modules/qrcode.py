from PyroUbot import *

__MODULE__ = "ǫʀ ᴄᴏᴅᴇ"
__HELP__ = """
<b>✭ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ǫʀ ᴄᴏᴅᴇ ✭</b>

<blockquote><b>perintah : <code>{0}qrGen</code>
    merubah qrcode text menjadi gambar

perintah : <code>{0}qrRead</code>
    merubah qrcode media menjadi text</b></blockquote>
"""

