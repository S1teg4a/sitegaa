__MODULE__ = "ᴄᴀʀʙᴏɴ"
__HELP__ = """
<blockquote><b>♛ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴀʀʙᴏɴ ♛<b>

<blockquote><b>perintah : 
<code>{0}carbon</code> untuk membuat text menjadi carbon</b></blockquote>
"""
