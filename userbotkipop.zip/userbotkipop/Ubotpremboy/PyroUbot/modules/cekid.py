__MODULE__ = "ᴄᴇᴋ ɪᴅ ᴜsᴇʀ"
__HELP__ = """
<blockquote><b>♛ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴇᴋ ɪᴅ ♛<b>

<blockquote><b>perintah : 
<code>{0}id</code> untuk melihat id user</b></blockquote>
"""
